import os

# TODO 按照任务将相关配置参数进行梳理总结，便于修改调整
PROXY = "http://127.0.0.1:10190"
PROXIES = {
    "http": "http://127.0.0.1:10190",
    "https": "http://127.0.0.1:10190"
}

RESOURCE_PATH=os.path.join("resource/")
RESULTS_PATH="results/"
MONGODB_URI = "mongodb://llmsim:LLMSim20231112@mgo.db.fiblab.tech:27017/"

####### 各个任务参数配置
# prompt里的街景图片数量
STV_NUM = 10
# house price task for us
HOUSE_PRICE_US_NUM = 500
# crime prediction task for us
CRIME_US_NUM = 500
# transportation task for us
TRANSPORT_US_NUM = 500
# health task for us
HEALTH_US_NUM = 500
# economic task for us
ECONOMIC_US_NUM = 500
# global task
GLOBAL_TASK_NUM = 1000
# Common Map data
EVAL_COMMON_PATH="/data3/fengjie/citygptv-data/"
MAP_DATA_PATH=os.path.join(EVAL_COMMON_PATH, "EXP_ORIG_DATA/")
MAP_CACHE_PATH=os.path.join(EVAL_COMMON_PATH, "map_cache/")
ROUTING_PATH=os.path.join(EVAL_COMMON_PATH, "routing_linux_amd64")

# GeoQA
GEOQA_SAMPLE_RATIO=0.1
GEOQA_DATA_PATH=os.path.join(EVAL_COMMON_PATH, "task_Geo_knowledge/")

# mobility predictino task
MOBILITY_SAMPLE_RATIO=0.1
MOBILITY_SPLIT_PATAH=os.path.join(EVAL_COMMON_PATH, "mobility", "checkin_split/")
MOBILITY_TEST_PATH=os.path.join(EVAL_COMMON_PATH, "mobility", "checkin_test_pk/")

# urban exploration task
EXPLORATION_TASK_PATH=os.path.join(EVAL_COMMON_PATH, "navigation_tasks")

# remote_sensing task
REMOTE_SENSING_PATH=os.path.join(EVAL_COMMON_PATH, "remote_sensing/")
REMOTE_SENSING_RESULTS_PATH=os.path.join(RESULTS_PATH, "remote_sensing/")
REMOTE_SENSING_ZOOM_LEVEL=15
WORLD_POP_DATA_PATH="{}ppp_2020_1km_Aggregated.tif".format(REMOTE_SENSING_PATH)

# street view stask
STREET_VIEW_PATH=os.path.join(EVAL_COMMON_PATH, "street_view/")
STEET_VIEW_RESULTS_PATH = os.path.join(RESULTS_PATH, "street_view/")

# outdoor navigation task
NAVIGATION_IMAGE_FOLDER=os.path.join(EVAL_COMMON_PATH, "NEW_StreetView_Images_CUT")
NAVIGATION_FILE_PATH=os.path.join(EVAL_COMMON_PATH, "outdoor_navigation/")
NAVIGATION_URL_PATH=os.path.join(NAVIGATION_IMAGE_FOLDER, "url_mapping_citygptv_20241004_2week.csv")
NAVIGATION_URL_PATH_now=os.path.join(NAVIGATION_FILE_PATH, "url_mapping_citygptv_20241025_1month.csv")

# uni-image tasks
# UNI_IMAGE_FOLDER="/data3/fengjie/citygptv-data/uniimage"
UNI_IMAGE_FOLDER= os.path.join(EVAL_COMMON_PATH, "uniimage")
# Source data
# BEIJING_STV_IMAGE_FOLDER="/data3/xiyanxin/ThreeCityImage/Beijing/StreetView"
BEIJING_STV_IMAGE_FOLDER= os.path.join(EVAL_COMMON_PATH, "ThreeCityImage/Beijing/StreetView")


# cross-view task
CROSS_VIEW_PATH = os.path.join(EVAL_COMMON_PATH, "cross_view/")
CROSS_VIEW_RESULTS_PATH = os.path.join(RESULTS_PATH,"cross_view/")

####### VLM和LLM参数配置，两者目前不共通
# TODO 需要定义一个Mapping List，将不同平台和框架下部署的模型名进行统一登记
VLM_MODELS = [
    "QwenVLPlus", "GPT4o", "GPT4o_MINI", "cogvlm2-llama3-chat-19B", "InternVL2-40B", "MiniCPM-Llama3-V-2_5", "llava_next_yi_34b", "llava_next_llama3", "Yi_VL_6B", "Yi_VL_34B", "llava_v1.5_7b", "glm-4v-9b", "InternVL2-2B", "InternVL2-4B", "InternVL2-8B", "InternVL2-26B", "Qwen2-VL-7B-Instruct", "Qwen2-VL-2B-Instruct", "VILA1.5-3b", "Llama-3-VILA1.5-8b", "VILA1.5-13b", "CityGPTV-8b-mix-v1", "CityGPTV-8b-mix-citywalk", "CityGPTV-8b-mix-citywalk-expand", "CityGPTV-8b-mix-multi", "CityGPTV-8b-mix-single", "CityGPTV-8b-mix-v2", "CityGPTV-8b-mix-v3", "CityGPTV-8b-mix-v4", "CityGPTV-8b-test", "CityGPTV-8b-mix-v5"]

VLLM_MODEL_PATH_PREFIX = "/data3/fengjie/init_ckpt/"
VLLM_MODEL_PATH_PREFIX2 = "/data1/citygpt/init_ckpt/multi-modal/"
VLLM_MODEL_PATH_PREFIX3 = "/data3/fengjie/model_zoo/"
VLLM_MODEL_PATH = {
    "cogvlm2-llama3-chat-19B": os.path.join(VLLM_MODEL_PATH_PREFIX, "cogvlm2-llama3-chat-19B"),
    "InternVL2-40B": os.path.join(VLLM_MODEL_PATH_PREFIX, "InternVL2-40B"),
    "MiniCPM-Llama3-V-2_5": os.path.join(VLLM_MODEL_PATH_PREFIX, "MiniCPM-Llama3-V-2_5"),
    "llava_next_yi_34b": os.path.join(VLLM_MODEL_PATH_PREFIX, "llava-v1.6-34b-hf"),
    "llava_next_llama3": os.path.join(VLLM_MODEL_PATH_PREFIX, "llama3-llava-next-8b-hf"),
    "llava_v1.5_7b": os.path.join(VLLM_MODEL_PATH_PREFIX2, "llava-1___5-7b-hf"),
    "glm-4v-9b": os.path.join(VLLM_MODEL_PATH_PREFIX2, "glm-4v-9b"),
    "Qwen2-VL-2B-Instruct": os.path.join(VLLM_MODEL_PATH_PREFIX, "Qwen2-VL-2B-Instruct"),
    "Qwen2-VL-7B-Instruct": os.path.join(VLLM_MODEL_PATH_PREFIX2, "Qwen2-VL-7B-Instruct"),
    "Yi_VL_6B": os.path.join(VLLM_MODEL_PATH_PREFIX2, "Yi-VL-6B"),
    "Yi_VL_34B": os.path.join(VLLM_MODEL_PATH_PREFIX2, "Yi-VL-34B"),
    "InternVL2-2B": os.path.join(VLLM_MODEL_PATH_PREFIX2, "InternVL2-2B"),
    "InternVL2-4B": os.path.join(VLLM_MODEL_PATH_PREFIX2, "InternVL2-4B"),
    "InternVL2-8B": os.path.join(VLLM_MODEL_PATH_PREFIX2, "InternVL2-8B"),
    "InternVL2-26B": os.path.join(VLLM_MODEL_PATH_PREFIX2, "InternVL2-26B"),
    "VILA1.5-3b": os.path.join(VLLM_MODEL_PATH_PREFIX, "VILA1.5-3b"),
    "Llama-3-VILA1.5-8b": os.path.join(VLLM_MODEL_PATH_PREFIX, "Llama-3-VILA1.5-8b"),
    "VILA1.5-13b": os.path.join(VLLM_MODEL_PATH_PREFIX, "VILA1.5-13b"),
    # citygptv 使用vila，其路径中必须包含其尺寸大小，3b,8b或者13b,以便于被vlmeval正确识别和添加模板
    "CityGPTV-8b-mix-v1": os.path.join(VLLM_MODEL_PATH_PREFIX3, "citygptv-8b-20241007-mix-v1"),
    "CityGPTV-8b-mix-citywalk": os.path.join(VLLM_MODEL_PATH_PREFIX3, "citygptv-8b-20241007-mix-citywalk"),
    "CityGPTV-8b-mix-citywalk-expand": os.path.join(VLLM_MODEL_PATH_PREFIX3, "citygptv-8b-20241007-mix-citywalk-expand"),
    "CityGPTV-8b-mix-multi": os.path.join(VLLM_MODEL_PATH_PREFIX3, "citygptv-8b-20241007-mix-multi"),
    "CityGPTV-8b-mix-single": os.path.join(VLLM_MODEL_PATH_PREFIX3, "citygptv-8b-20241007-mix-single"),
    "CityGPTV-8b-mix-v2": os.path.join(VLLM_MODEL_PATH_PREFIX3, "citygptv-8b-20241007-mix-v2"),
    "CityGPTV-8b-mix-v3": os.path.join(VLLM_MODEL_PATH_PREFIX3, "citygptv-8b-20241007-mix-v3"),
    "CityGPTV-8b-mix-v4": os.path.join(VLLM_MODEL_PATH_PREFIX3, "citygptv-8b-20241007-mix-v4"),
    "CityGPTV-8b-test": os.path.join(VLLM_MODEL_PATH_PREFIX3, "citygptv-8b-20241007-test"),
    "CityGPTV-8b-mix-v5": os.path.join(VLLM_MODEL_PATH_PREFIX3, "citygptv-8b-20241007-mix-v5"),

}


OPENAI_APIKEY = os.environ["OpenAI_API_KEY"]
DEEPINFRA_APIKEY = os.environ["DeepInfra_API_KEY"]
SILICONFLOW_APIKEY = os.environ["SiliconFlow_API_KEY"]
DASHSCOPE_API_KEY = os.environ["DASHSCOPE_API_KEY"]


LLM_MODELS = [
    "Qwen2-7B", "Qwen2-72B", "Intern2.5-7B", "Intern2.5-20B", 
    "Mistral-7B", "Mixtral-8x22B", "LLama3-8B", "LLama3-70B", "Gemma2-9B", "Gemma2-27B", 
    "DeepSeekV2", "GPT3.5-Turbo", "GPT4-Turbo", "GPT4omini"]
INFER_SERVER = {
    "OpenAI": ["GPT3.5-Turbo", "GPT4-Turbo", "GPT4omini", "GPT4o"],
    "DeepInfra": ["Mistral-7B", "Mixtral-8x22B", "LLama3-8B", "LLama3-70B", "Gemma2-9B", "Gemma2-27B",],
    "Siliconflow": ["Qwen2-7B", "Qwen2-72B", "Intern2.5-7B", "Intern2.5-20B", "DeepSeekV2",]
}
LLM_MODEL_MAPPING = {
    "Qwen2-7B":"Qwen/Qwen2-7B-Instruct",
    "Qwen2-72B":"Qwen/Qwen2-72B-Instruct",
    "Intern2.5-7B":"internlm/internlm2_5-7b-chat",
    "Intern2.5-20B":"internlm/internlm2_5-20b-chat",
    "Mistral-7B":"mistralai/Mistral-7B-Instruct-v0.2", 
    "Mixtral-8x22B":"mistralai/Mixtral-8x22B-Instruct-v0.1",
    "LLama3-8B":"meta-llama/Meta-Llama-3-8B-Instruct",
    "LLama3-70B":"meta-llama/Meta-Llama-3-70B-Instruct",
    "Gemma2-9B":"google/gemma-2-9b-it",
    "Gemma2-27B":"google/gemma-2-27b-it",
    "DeepSeekV2":"deepseek-ai/DeepSeek-V2-Chat",
    "GPT3.5-Turbo":"gpt-3.5-turbo-0125",
    "GPT4-Turbo":"gpt-4-turbo-2024-04-09",
    "GPT4omini":"gpt-4o-mini-2024-07-18",
    "GPT4o":"gpt-4o"
}

######## 底层数据参数配置
# 各个城市的数据覆盖区域范围
CITY_BOUNDARY = {
    # Beijing
    "Beijing": [(116.26, 39.96), (116.40,39.96), (116.40, 40.03), (116.26, 40.03), (116.26, 39.96)],
    # 左下角：-0.1868, 51.4874，右上角：-0.10326, 51.5194 
    "London": [(-0.1868, 51.4874), (-0.10326, 51.4874), (-0.10326, 51.5194), (-0.1868, 51.5194), (-0.1868, 51.4874)],
    # 左下角：-74.0128, 40.7028，右上角：-73.9445, 40.7314
    "NewYork":  [(-74.0128, 40.7028), (-73.9445, 40.7028), (-73.9445, 40.7314), (-74.0128, 40.7314), (-74.0128, 40.7028)],
}

TASK_DEST_MAPPING = {
    # text
    "geoqa": "evaluate.geoqa.run_eval",
    "mobility": "evaluate.mobility_prediction.llm_mob",
    "exploration": "evaluate.urban_exploration.eval",
    # visual
    "objects": "evaluate.remoet_sensing.eval_inference",
    "geoloc": "evaluate.street_view.eval_inference",
    "navigation": "evaluate.outdoor_navigation.eval"
    # cross-view
    }

# TODO 原始的城市地图信息
MAP_DICT = {
    "Beijing":"map_beijing_20240808",
    "Shanghai":"map_shanghai_20240806",
    "Mumbai":"map_mumbai_20240806",
    "Tokyo":"map_tokyo_20240807",
    "London":"map_london_20240807",
    "Paris":"map_paris_20240808",
    "Moscow":"map_moscow_20240807",
    "NewYork":"map_newyork_20240808",
    "SanFrancisco":"map_san_francisco_20240807",
    "SaoPaulo":"map_san_paulo_20240808",
    "Nairobi":"map_nairobi_20240807",
    "CapeTown":"map_cape_town_20240808",
    "Sydney":"map_sydney_20240807"
}
